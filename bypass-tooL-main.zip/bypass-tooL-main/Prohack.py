
import platform

z=platform.platform()

import by
by.qaiser()
